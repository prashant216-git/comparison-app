package flightcompare.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import flightcompare.DTO.SignIn;
import flightcompare.DTO.SigninDto;
import flightcompare.DTO.UserDto;
import flightcompare.model.SignupUser;
import flightcompare.repo.UserRepo;
import flightcompare.service.SigninService;
import flightcompare.ulitit.JwtGenerator;
@Service
public class SigninServiceImplementation implements SigninService {
@Autowired
private UserRepo repo;
@Autowired
private JwtGenerator jwtGenerator;
	@Override
	public String signin(SigninDto signinDto) {
		SignupUser user=repo.findByUsername(signinDto.getUsername())!=null? repo.findByUsername(signinDto.getUsername()):null;
			if(user==null) {
				throw new RuntimeException("Username not found");
			}
			else {
				if(!user.getPassword().equals(signinDto.getPassword()) && user.getPassword()!=null) {
					throw new RuntimeException("Invalid password");
				}
				else {
					String token = jwtGenerator.generateToken(user.getUsername());
					return token;
				}
			}
	
		
	}

}
