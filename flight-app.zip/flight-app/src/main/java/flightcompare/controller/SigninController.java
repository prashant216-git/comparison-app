package flightcompare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import flightcompare.DTO.SignIn;
import flightcompare.DTO.SigninDto;
import flightcompare.DTO.UserDto;
import flightcompare.service.SigninService;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/signin")
public class SigninController {
	@Autowired
	private SigninService signinService;

	
	  @PostMapping 
	  public ResponseEntity<String> signin(@RequestBody SigninDto
	  userDto) {
	  System.out.println("SigninController: Received signin request for user: " +userDto.getUsername());
	  String token=signinService.signin(userDto); 
	  return 
	  ResponseEntity.status(HttpStatus.OK).body(token); }
	 
	


}
