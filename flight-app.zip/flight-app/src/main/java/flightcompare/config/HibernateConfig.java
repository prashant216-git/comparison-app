package flightcompare.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;

import flightcompare.multitenant.MultiTenantConnectionProviderImpl;
import flightcompare.multitenant.CurrentTenantIdentifierResolverImpl;

import javax.sql.DataSource;

@Configuration
public class HibernateConfig {

    @Bean(name = "multiTenantConnectionProvider")
    public MultiTenantConnectionProvider multiTenantConnectionProvider(DataSource dataSource) {
        return new MultiTenantConnectionProviderImpl(dataSource);
    }

    @Bean(name = "currentTenantIdentifierResolver")
    public CurrentTenantIdentifierResolver currentTenantIdentifierResolver() {
        return new CurrentTenantIdentifierResolverImpl();
    }
}
