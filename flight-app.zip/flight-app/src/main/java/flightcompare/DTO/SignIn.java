package flightcompare.DTO;

import lombok.Data;

@Data
public class SignIn {

	private String userName;
	private String password;
}
