package flightcompare.TenantService;

import org.springframework.stereotype.Component;

@Component
public class TenantContext {
private static final ThreadLocal<String> currentTenant = new ThreadLocal<>();

	public static void setCurrentTenant(String object) {
		currentTenant.set(object);
	}

	public static String getCurrentTenant() {
		return currentTenant.get();
	}

	public static void clear() {
		currentTenant.remove();
	}
}
