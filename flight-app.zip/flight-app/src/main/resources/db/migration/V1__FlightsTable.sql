
-- V1__FlightsTable.sql
CREATE TABLE flights (
  id BIGSERIAL PRIMARY KEY,
  flight_name VARCHAR(255),
  source VARCHAR(100),
  destination VARCHAR(100),
  departure_time VARCHAR(50),
  arrival_time VARCHAR(50),
  duration VARCHAR(50),
  price DOUBLE PRECISION,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_source on flights(source);
CREATE INDEX idx_dest on flights(destination);
